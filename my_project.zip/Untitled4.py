frutas = ("banana", "mamao", "melancia", "uva", "morango")
alergias = ("pera", "abacate", "melancia", "kiwi")
for i in frutas:
    if i in alergias:
        print(i)